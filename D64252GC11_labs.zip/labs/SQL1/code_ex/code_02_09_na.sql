SELECT last_name, hire_date,salary
FROM employees;

