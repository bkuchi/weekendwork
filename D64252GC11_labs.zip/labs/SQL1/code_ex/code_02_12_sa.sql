SELECT last_name, salary, salary + 300
FROM   employees;