SELECT last_name, 12*salary*commission_pct
FROM   employees;
