SELECT	last_name||job_id AS "Employees"
FROM 	employees;