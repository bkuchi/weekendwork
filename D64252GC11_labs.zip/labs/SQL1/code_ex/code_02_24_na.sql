SELECT  DISTINCT department_id, job_id
FROM    employees;