SELECT last_name, salary
FROM   employees
WHERE  salary <= 3000 ;
