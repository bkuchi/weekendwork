SELECT last_name, department_id, salary*12
FROM   employees
WHERE  job_id = '&job_title' ;
