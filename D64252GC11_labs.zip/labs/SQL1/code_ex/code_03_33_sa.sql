SELECT   employee_id, last_name, job_id, &&column_name
FROM     employees
ORDER BY &column_name ;
