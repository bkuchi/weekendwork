SELECT last_name, hire_date
FROM   employees
WHERE  hire_date < '01-FEB-88';
