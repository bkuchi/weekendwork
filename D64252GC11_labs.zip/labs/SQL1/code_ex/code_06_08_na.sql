SELECT MIN(last_name), MAX(last_name)
FROM   employees;

