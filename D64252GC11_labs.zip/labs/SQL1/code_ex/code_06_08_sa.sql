SELECT MIN(hire_date), MAX(hire_date)
FROM	  employees;

