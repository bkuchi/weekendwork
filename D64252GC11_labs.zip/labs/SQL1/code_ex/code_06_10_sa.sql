SELECT COUNT(DISTINCT department_id)
FROM   employees;
