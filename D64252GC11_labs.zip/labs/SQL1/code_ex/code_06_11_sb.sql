SELECT AVG(NVL(commission_pct, 0))
FROM   employees;
