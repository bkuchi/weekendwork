SELECT last_name, department_name
FROM   employees
CROSS JOIN departments ;
