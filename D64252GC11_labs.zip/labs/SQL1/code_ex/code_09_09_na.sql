DESCRIBE employees
