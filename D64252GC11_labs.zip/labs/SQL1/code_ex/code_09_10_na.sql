SELECT employee_id, last_name, job_id, hire_date, department_id 
FROM employees;
