DESCRIBE  departments
