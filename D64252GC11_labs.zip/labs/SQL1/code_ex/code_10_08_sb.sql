INSERT INTO	departments
VALUES		(100, 'Finance', NULL, NULL);
