UPDATE employees
SET    department_id = 50
WHERE  employee_id = 113;
