UPDATE 	copy_emp
SET    	department_id = 110;
