DELETE FROM  departments WHERE department_id IN (30, 40);
