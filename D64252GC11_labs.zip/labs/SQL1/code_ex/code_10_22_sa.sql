DELETE FROM departments
 WHERE  department_name = 'Finance';
