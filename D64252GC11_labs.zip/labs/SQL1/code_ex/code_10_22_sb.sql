DELETE FROM  copy_emp;
