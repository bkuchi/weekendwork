UPDATE  employees
     SET   department_id = 80
     WHERE employee_id = 206;
