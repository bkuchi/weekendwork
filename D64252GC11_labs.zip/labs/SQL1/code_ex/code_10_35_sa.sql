DELETE FROM employees
WHERE  employee_id = 99999;

INSERT INTO departments 
VALUES (290, 'Corporate Tax', NULL, 1700);
