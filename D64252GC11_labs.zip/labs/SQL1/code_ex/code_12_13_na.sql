SELECT  * 
FROM    dept_sum_vu;

