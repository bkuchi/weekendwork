SELECT	dept_deptid_seq.CURRVAL
FROM	dual;
