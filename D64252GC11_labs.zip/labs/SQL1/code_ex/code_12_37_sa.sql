CREATE INDEX 	emp_last_name_idx
ON 		employees(last_name);
