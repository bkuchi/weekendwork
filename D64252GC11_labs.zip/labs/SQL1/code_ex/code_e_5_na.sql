SELECT last_name, department_name dept_name
   FROM   employees, departments;
