SELECT	last_name, salary, department_id, job_id
FROM	employees
WHERE	department_id = 80
AND	job_id = 'SA_REP'
/
