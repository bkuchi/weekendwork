SELECT	last_name, hire_date
FROM 	employees
WHERE	hire_date BETWEEN '20-FEB-1991' AND '17-NOV-1993'
/
