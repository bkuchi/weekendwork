SELECT     last_name, salary, department_id
FROM       employees
WHERE      salary >= 4500
AND        (department_id = 50
OR          department_id = 60)
/
