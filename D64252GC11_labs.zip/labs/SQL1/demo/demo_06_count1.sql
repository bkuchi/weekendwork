SELECT	COUNT(*)
FROM 	employees
/
