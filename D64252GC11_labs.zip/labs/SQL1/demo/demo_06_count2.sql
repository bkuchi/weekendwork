SELECT	COUNT(commission_pct)
FROM 	employees
/
