SELECT * 
FROM   teach_a.departments
/
