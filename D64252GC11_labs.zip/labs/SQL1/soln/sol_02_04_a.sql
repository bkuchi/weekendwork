DESCRIBE departments

