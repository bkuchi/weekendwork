DESCRIBE employees

