SELECT  last_name, department_id
FROM    employees 
WHERE   employee_id = 176;
