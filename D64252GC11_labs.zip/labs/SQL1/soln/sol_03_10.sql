SELECT  last_name, salary
FROM    employees 
WHERE   salary > &sal_amt; 
