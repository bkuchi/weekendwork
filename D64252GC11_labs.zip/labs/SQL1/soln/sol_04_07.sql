SELECT last_name,
       LPAD(salary, 15, '$') SALARY
FROM   employees;
