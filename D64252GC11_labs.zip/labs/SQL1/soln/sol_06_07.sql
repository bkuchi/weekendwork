SELECT COUNT(DISTINCT manager_id) "Number of Managers"
FROM   employees; 

