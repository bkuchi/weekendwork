SELECT   MAX(salary) - MIN(salary) DIFFERENCE
FROM     employees;

