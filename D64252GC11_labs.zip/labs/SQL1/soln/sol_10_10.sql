UPDATE  my_employee
SET     last_name = 'Drexler'
WHERE   id = 3;

