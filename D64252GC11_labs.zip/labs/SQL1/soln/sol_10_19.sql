DELETE 
FROM  my_employee;
