SELECT * 
FROM my_employee 
WHERE ID='6';
