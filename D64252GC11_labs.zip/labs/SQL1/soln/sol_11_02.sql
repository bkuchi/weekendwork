INSERT INTO dept
  SELECT  department_id, department_name
  FROM    departments;
