SELECT   *
FROM     employees_vu;   
