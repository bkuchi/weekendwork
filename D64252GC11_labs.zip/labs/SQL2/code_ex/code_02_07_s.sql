--This can be executed by only teach_b account
CREATE USER demo
IDENTIFIED BY demo;