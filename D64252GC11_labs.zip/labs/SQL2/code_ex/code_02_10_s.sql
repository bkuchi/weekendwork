--This can be executed only by teach_b account
GRANT create session, create table, create sequence, create view
TO demo;