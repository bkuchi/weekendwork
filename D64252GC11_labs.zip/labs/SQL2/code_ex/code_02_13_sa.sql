CREATE ROLE manager;
