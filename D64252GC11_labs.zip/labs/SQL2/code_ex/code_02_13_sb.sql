--This can be executed only by teach_b account
GRANT create table, create view 		  
TO manager; 

