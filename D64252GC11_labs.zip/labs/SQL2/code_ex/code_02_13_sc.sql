--This can be executed only by teach_b account
Create user alice identified by alice;
GRANT create session TO alice;
Grant manager to alice;