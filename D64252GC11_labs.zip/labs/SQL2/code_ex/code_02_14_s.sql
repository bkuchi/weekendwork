--This can be executed only by teach_b or demo account
ALTER USER demo          			  
IDENTIFIED BY employ;

