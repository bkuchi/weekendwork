--This can be executed only by teach_b account.

GRANT SELECT ON employees TO demo;