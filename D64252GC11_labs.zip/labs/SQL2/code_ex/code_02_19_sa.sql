--This can be executed only by teach_b account.
--grant the privileges
GRANT select,insert ON departments TO demo WITH GRANT OPTION;