--revoke the privileges
--This can be executed only by teach_b account.
REVOKE select,insert ON departments FROM demo;