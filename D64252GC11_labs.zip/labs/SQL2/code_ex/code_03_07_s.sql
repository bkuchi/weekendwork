ALTER TABLE dept80
MODIFY(last_name VARCHAR2(30));




