ALTER TABLE  dept80
DROP (job_id);

select * from dept80;
