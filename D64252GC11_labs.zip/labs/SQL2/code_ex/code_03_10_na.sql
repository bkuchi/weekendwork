ALTER TABLE  dept80
SET   UNUSED (last_name);


