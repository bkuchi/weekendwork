-- Turn the autocommit option off, and execute the insert statement
-- SET AUTOCOMMIT OFF
INSERT INTO emp_new_sal VALUES(110,-1);
