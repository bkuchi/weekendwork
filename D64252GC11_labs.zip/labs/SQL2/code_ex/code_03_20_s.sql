ALTER TABLE emp2
ENABLE CONSTRAINT emp_dt_fk;




