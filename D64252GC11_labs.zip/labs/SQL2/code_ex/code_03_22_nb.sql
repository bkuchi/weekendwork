ALTER TABLE test1 DROP (col1_pk);  




