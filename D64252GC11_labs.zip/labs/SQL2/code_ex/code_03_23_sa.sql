ALTER TABLE emp2 
DROP column employee_id CASCADE CONSTRAINTS;




