--rename the column
ALTER TABLE marketing RENAME COLUMN team_id TO id;
