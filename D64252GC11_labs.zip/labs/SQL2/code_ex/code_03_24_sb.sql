--rename the constraint
ALTER TABLE marketing RENAME CONSTRAINT mktg_pk TO new_mktg_pk;
