set autotrace on

SELECT * FROM emp2 WHERE UPPER(last_name) = 'KING';




CREATE INDEX upper_last_name_idx ON emp2 (UPPER(last_name));



SELECT * FROM emp2 WHERE UPPER(last_name) = 'KING';


SELECT * FROM employees 
WHERE UPPER(last_name) IS NOT NULL
ORDER BY UPPER(last_name);

set autotrace off;