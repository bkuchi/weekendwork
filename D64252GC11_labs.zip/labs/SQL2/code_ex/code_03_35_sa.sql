DROP TABLE emp2;

SELECT original_name, operation, droptime FROM recyclebin;

