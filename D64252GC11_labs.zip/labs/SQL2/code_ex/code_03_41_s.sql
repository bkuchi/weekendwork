--This code should be executed using the teach_b account
CREATE OR REPLACE DIRECTORY emp_dir 
AS '/home/oracle/labs/sql2/emp_dir'; 
GRANT READ ON DIRECTORY emp_dir TO ora21;
